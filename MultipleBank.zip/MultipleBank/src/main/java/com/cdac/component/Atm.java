package com.cdac.component;

import org.springframework.stereotype.Component;


public interface Atm {

	public void Withdraw(int accno,int accno1,double amount);
}
