package com.cdac.component;


public interface Bank {

	public boolean isAccountNumber(int anco);
	public void Withdraw(int  anco,int accno,double amount);
}
