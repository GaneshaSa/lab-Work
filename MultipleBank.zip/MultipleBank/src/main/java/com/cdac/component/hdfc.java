package com.cdac.component;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class hdfc implements Atm{

	@Autowired
	private List<Bank> bank;
	public void Withdraw(int accno,int accno1, double amount) {
		// TODO Auto-generated method stub
	System.out.println("welcome to hdfc bank atm");
	Bank currBank=null;
	for(Bank p:bank)
		if(p.isAccountNumber(accno))
		{
			currBank=p;
		}
	currBank.Withdraw(1011, 88, 5000);
	}
	

}
