package com.cdac.app;

import java.time.LocalDate;

import com.cdac.dao.PersonPassportDao;
import com.cdac.entity.Passport;
import com.cdac.entity.Person;

public class PersonPassportExample {

	public static void main(String[] args) {
		PersonPassportDao dao = new PersonPassportDao();
		
		Person p = new Person();
		p.setName("Ganesh");
		p.setEmail("ganesh@gmail.com");
		p.setDateOfBirth(LocalDate.of(1999, 5, 15));
		
		Passport pq = new Passport();
		pq.setIssueDate(LocalDate.of(2020, 10, 30));	
		pq.setExpiryDate(LocalDate.of(2030, 10, 30));
		pq.setIssuedBy("India");
		
		p.setPassport(pq);
		pq.setPerson(p);
		
		dao.add(p);
	}
}

