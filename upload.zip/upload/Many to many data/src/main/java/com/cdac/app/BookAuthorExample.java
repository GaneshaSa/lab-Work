package com.cdac.app;

import java.util.ArrayList;
import java.util.List;

import com.cdac.dao.GenericDao;
import com.cdac.entity.Author;
import com.cdac.entity.Book;

public class BookAuthorExample {

	public static void main(String[] args) {
		GenericDao dao = new GenericDao();
		
		Book book = new Book();
		book.setName("Groovy 2 Cookbook");
		book.setCost(3000);
		
		Author author1 = new Author();
		author1.setName("yogesh");
		author1.setEmail("Yogesh@gmail.com");
		
		Author author2 = new Author();
		author2.setName("ganesh");
		author2.setEmail("ganesh@gmail.com");
		
		List<Author> list1 = new ArrayList<Author>();
		list1.add(author1);
		list1.add(author2);
		
		book.setAuthors(list1);
		
		dao.save(book);
	
	}
}
