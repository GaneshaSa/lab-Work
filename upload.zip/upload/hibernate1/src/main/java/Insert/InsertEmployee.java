package Insert;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import cdac.java.Employee;

public class InsertEmployee {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em =emf.createEntityManager();
		EntityTransaction tx =em.getTransaction();
		tx.begin();
		
	Employee emp=new Employee();
	emp.setEmpno(1001);
	emp.setEname("ganesh");
    emp.setSalary("5000");
    em.persist(emp);
    tx.commit();
    emf.close();
	
	}
}
