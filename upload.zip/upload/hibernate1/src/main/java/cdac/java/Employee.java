package cdac.java;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table (name = "table1")
public class Employee {
@Id	
@Column(name="empno")	
private int empno;
@Column(name="ename")
private String ename;
@Column(name="salary")
private String salary;


public String getEname() {
	return ename;
}

public void setEname(String ename) {
	this.ename = ename;
}

public String getSalary() {
	return salary;
}

public void setSalary(String salary) {
	this.salary = salary;
}


public void setEmpno(int empno) {
	this.empno = empno;
}

public int getEmpno() {
	return empno;
}
	

}